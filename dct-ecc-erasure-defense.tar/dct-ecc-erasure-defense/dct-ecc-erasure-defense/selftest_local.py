from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
COMMANDS = [
    ["generate_scene.py"],
    ["analyze_dct_capacity.py"],
    ["design_block_mask.py"],
    ["ecc_encode_message.py"],
    ["build_interleaver.py"],
    ["embed_ecc_watermark.py", "--alpha", "34"],
    ["simulate_geometric_damage.py", "--mode", "crop_shift", "--crop", "18", "--dx", "9", "--dy", "-6"],
    ["simulate_geometric_damage.py", "--mode", "rotate_scale", "--angle", "4", "--scale", "0.94"],
    ["extract_raw_bits.py", "--image", "attack_crop_shift.png", "--out", "raw_crop_report.txt"],
    ["extract_raw_bits.py", "--image", "attack_rotation_scale.png", "--out", "raw_rot_report.txt"],
    ["detect_erasure_blocks.py", "--image", "attack_crop_shift.png"],
    ["decode_with_ecc.py", "--raw", "raw_crop_report.txt", "--erasure", "erasure_report.txt"],
    ["adaptive_tile_recovery.py", "--image", "attack_rotation_scale.png"],
    ["simulate_geometric_damage.py", "--mode", "challenge"],
    ["extract_raw_bits.py", "--image", "challenge_damage.png", "--out", "challenge_raw_report.txt"],
    ["detect_erasure_blocks.py", "--image", "challenge_damage.png", "--out", "challenge_erasure_report.txt"],
    ["adaptive_tile_recovery.py", "--image", "challenge_damage.png", "--out", "challenge_recovery_report.txt"],
    ["visualize_damage_maps.py"],
    ["write_recovery_memo.py"],
    ["summary.py"],
]
CHECKS = {
    "scene_report.txt": "Cover scene generated",
    "dct_capacity_report.txt": "DCT capacity analysis completed",
    "block_mask_report.txt": "DCT block mask accepted",
    "ecc_report.txt": "ECC payload encoded",
    "interleaver_report.txt": "Interleaver map generated",
    "embed_ecc_report.txt": "ECC DCT watermark embedded",
    "crop_shift_attack_report.txt": "Geometric damage attacks generated",
    "raw_crop_report.txt": "Raw attacked extraction completed",
    "erasure_report.txt": "Erasure blocks detected",
    "ecc_decode_report.txt": "ECC erasure decoding completed",
    "adaptive_recovery_report.txt": "Adaptive tile recovery passed",
    "challenge_recovery_report.txt": "Unknown geometric erasure challenge recovered",
    "visual_report.txt": "Visual damage evidence completed",
    "memo_report.txt": "ECC erasure defense memo accepted",
    "summary_report.txt": "DCT ECC erasure defense summary completed",
}


def maybe_write_solution() -> None:
    if os.environ.get("DCT_ECC_ERASURE_SELFTEST_SOLUTION") != "1":
        return
    (ROOT / "block_config.py").write_text(
        "\n".join(
            [
                "MIN_DCT_ENERGY = 22.0",
                "MAX_SMOOTHNESS = 65.0",
                "EXCLUDE_BORDER_BLOCKS = 2",
                "USE_TEXTURE_ONLY = True",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "ecc_config.py").write_text(
        "\n".join(
            [
                'ECC_MODE = "hamming_parity"',
                "PARITY_BYTES = 12",
                "REPEAT_FACTOR = 3",
                "LANE_COUNT = 6",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "interleaver_config.py").write_text(
        "\n".join(
            [
                'INTERLEAVER_MODE = "tile_spread"',
                "STRIDE_X = 7",
                "STRIDE_Y = 11",
                "SHUFFLE_SEED = 164",
                "MIN_TILE_DISTANCE = 3",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "recovery_config.py").write_text(
        "\n".join(
            [
                'ERASURE_MODE = "coeff_margin"',
                "CONFIDENCE_THRESHOLD = 0.58",
                "MIN_COEFF_MARGIN = 6.5",
                'TILE_WEIGHT_MODE = "survival_confidence"',
                "DROP_WORST_TILES = 3",
                'LANE_VOTING = "weighted"',
                "MIN_TILE_SURVIVAL = 0.42",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (ROOT / "RECOVERY_MEMO.md").write_text(
        "\n".join(
            [
                "# Recovery Memo",
                "",
                "## Why raw extraction failed",
                "",
                "Raw BER increased because crop-shift and rotation-scale damage blanked or distorted whole groups of DCT blocks. The raw extractor still tried to read every block, so damaged blocks became confident-looking wrong bits or low-confidence random bits.",
                "",
                "## How interleaving reduced burst errors",
                "",
                "Interleaving spread adjacent encoded bits and repeated copies across distant tiles. A crop no longer removed a continuous message segment; it created scattered erasures that the repeat factor and ECC parity could absorb.",
                "",
                "## How erasure detection improved recovery",
                "",
                "The erasure detector used coefficient margin and confidence thresholding. Blocks with weak DCT separation were not trusted, which reduced the Corrected BER compared with raw voting. The Erasure rate was kept in the useful middle range instead of erasing almost everything.",
                "",
                "## Why some tiles were dropped",
                "",
                "Tiles with low Tile survival rate were probably padding, crop edge, or heavily interpolated regions. Dropping bad tile groups prevented them from dominating weighted voting and let surviving tiles carry the recovery.",
                "",
                "## Remaining weaknesses",
                "",
                "The defense is still weak against a global desynchronization that shifts every block boundary, a very large crop, or perspective warping. It improves robustness by design, but it does not replace registration for severe transforms.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def remove_outputs() -> None:
    for pattern in ["*.png", "*.txt", "*.json", "*.npz", "*.bin"]:
        for path in ROOT.glob(pattern):
            if path.name in {"STUDENT_GUIDE.md"}:
                continue
            path.unlink()


def run_command(command: list[str]) -> bool:
    proc = subprocess.run([sys.executable, *command], cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        print(f"FAIL {' '.join(command)}")
        print(proc.stdout)
        print(proc.stderr)
        return False
    print(f"PASS {' '.join(command)}")
    return True


def check_reports() -> bool:
    ok = True
    for name, marker in CHECKS.items():
        text = (ROOT / name).read_text(encoding="utf-8") if (ROOT / name).exists() else ""
        if marker in text:
            print(f"PASS check {name}")
        else:
            print(f"FAIL check {name}: missing {marker}")
            ok = False
    return ok


def main() -> int:
    remove_outputs()
    maybe_write_solution()
    ok = True
    for command in COMMANDS:
        ok = run_command(command) and ok
    ok = check_reports() and ok
    print("PASS selftest_local.py" if ok else "FAIL selftest_local.py")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())

