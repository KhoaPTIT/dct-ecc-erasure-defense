# TODO: choose interleaving strategy
INTERLEAVER_MODE = "sequential"
STRIDE_X = 1
STRIDE_Y = 1
SHUFFLE_SEED = 0
MIN_TILE_DISTANCE = 0
