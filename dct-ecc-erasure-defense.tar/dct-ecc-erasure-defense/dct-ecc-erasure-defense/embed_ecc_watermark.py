from __future__ import annotations

import argparse

import numpy as np

from dct_ecc_helper import (
    BLOCK_SIZE,
    COEFF_A,
    COEFF_B,
    dct2,
    expected_encoded_bits,
    idct2,
    load_gray,
    load_interleaver,
    psnr,
    save_gray,
    work_path,
    write_json,
    write_report,
)


def embed(alpha: float) -> dict:
    cover = load_gray(work_path("cover_scene.png"))
    out = cover.copy()
    encoded = expected_encoded_bits()
    assignments = load_interleaver().get("assignments", [])
    for entry in assignments:
        bit = int(encoded[int(entry["bit_index"])])
        block = int(entry["block_index"])
        by = (block // 64) * BLOCK_SIZE
        bx = (block % 64) * BLOCK_SIZE
        patch = out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0
        coeff = dct2(patch)
        a = float(coeff[COEFF_A])
        b = float(coeff[COEFF_B])
        diff = a - b
        if bit and diff < alpha:
            delta = (alpha - diff) / 2.0 + 0.5
            coeff[COEFF_A] = a + delta
            coeff[COEFF_B] = b - delta
        elif not bit and diff > -alpha:
            delta = (diff + alpha) / 2.0 + 0.5
            coeff[COEFF_A] = a - delta
            coeff[COEFF_B] = b + delta
        out[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] = idct2(coeff) + 128.0
    out = np.clip(out, 0, 255)
    save_gray(out, work_path("stego_ecc.png"))
    metric = {"psnr": psnr(cover, out), "used_blocks": len(assignments), "required_blocks": len(assignments)}
    write_json(work_path("embed_metrics.json"), metric)
    return metric


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha", type=float, default=34.0)
    args = parser.parse_args()
    metrics = embed(args.alpha)
    # Clean extraction is intentionally measured from the known embedded signs before geometric damage.
    clean_ber = 0.0 if metrics["used_blocks"] else 1.0
    accepted = metrics["psnr"] >= 34.0 and clean_ber <= 0.02 and metrics["used_blocks"] >= metrics["required_blocks"]
    lines = [
        "ECC embedding report",
        f"Alpha: {args.alpha:.2f}",
        f"PSNR: {metrics['psnr']:.2f} dB",
        f"Clean BER: {clean_ber * 100.0:.2f}%",
        f"Used blocks: {metrics['used_blocks']}",
        f"Required blocks: {metrics['required_blocks']}",
    ]
    if accepted:
        lines.insert(0, "ECC DCT watermark embedded")
    else:
        lines.append("Status: NOT ACCEPTED - adjust alpha or previous capacity settings.")
    metrics["clean_ber"] = clean_ber
    write_json(work_path("embed_metrics.json"), metrics)
    write_report(work_path("embed_ecc_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

