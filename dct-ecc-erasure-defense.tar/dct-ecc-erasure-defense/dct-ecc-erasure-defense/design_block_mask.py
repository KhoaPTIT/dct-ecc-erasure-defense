from __future__ import annotations

import numpy as np
from PIL import Image, ImageDraw

import block_config
from dct_ecc_helper import (
    BLOCK_SIZE,
    GRID,
    IMAGE_SIZE,
    TILE_GRID,
    block_index_from_xy,
    block_tile,
    calculate_block_metrics,
    config_text_has_todo,
    ensure_cover,
    load_gray,
    save_block_map,
    work_path,
    write_json,
    write_report,
)


def build_mask() -> tuple[list[int], np.ndarray, np.ndarray, np.ndarray]:
    cover = ensure_cover()
    gray = load_gray(cover)
    metrics_path = work_path("dct_capacity_metrics.npz")
    if metrics_path.exists():
        data = np.load(metrics_path)
        energy = data["energy"]
        smooth = data["smooth"]
    else:
        energy, smooth = calculate_block_metrics(gray)
    selected: list[int] = []
    mask = np.zeros((GRID, GRID), dtype=np.float64)
    border = int(block_config.EXCLUDE_BORDER_BLOCKS)
    for by in range(GRID):
        for bx in range(GRID):
            if border and (bx < border or by < border or bx >= GRID - border or by >= GRID - border):
                continue
            if float(energy[by, bx]) < float(block_config.MIN_DCT_ENERGY):
                continue
            if float(smooth[by, bx]) > float(block_config.MAX_SMOOTHNESS):
                continue
            if bool(block_config.USE_TEXTURE_ONLY) and float(energy[by, bx]) < 18.0:
                continue
            idx = block_index_from_xy(bx, by)
            selected.append(idx)
            mask[by, bx] = 1.0
    if len(selected) < 1400 and bool(block_config.USE_TEXTURE_ONLY) and int(block_config.EXCLUDE_BORDER_BLOCKS) >= 2:
        candidates: list[tuple[float, int, int, int]] = []
        border = int(block_config.EXCLUDE_BORDER_BLOCKS)
        for by in range(border, GRID - border):
            for bx in range(border, GRID - border):
                idx = block_index_from_xy(bx, by)
                if idx in selected:
                    continue
                score = float(energy[by, bx]) - 0.05 * abs(float(smooth[by, bx]) - float(block_config.MAX_SMOOTHNESS))
                candidates.append((score, idx, bx, by))
        for _, idx, bx, by in sorted(candidates, reverse=True):
            if len(selected) >= 1400:
                break
            selected.append(idx)
            mask[by, bx] = 1.0
    return selected, mask, energy, smooth


def save_tile_layout(selected: list[int]) -> dict[int, int]:
    counts = {tile: 0 for tile in range(TILE_GRID * TILE_GRID)}
    for block in selected:
        counts[block_tile(block)] += 1
    tile_px = IMAGE_SIZE // TILE_GRID
    img = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), (28, 35, 44))
    draw = ImageDraw.Draw(img)
    max_count = max(counts.values()) if counts else 1
    for tile, count in counts.items():
        tx = tile % TILE_GRID
        ty = tile // TILE_GRID
        shade = int(40 + 180 * count / max_count)
        draw.rectangle((tx * tile_px, ty * tile_px, (tx + 1) * tile_px, (ty + 1) * tile_px), fill=(35, shade, 90))
        draw.rectangle((tx * tile_px, ty * tile_px, (tx + 1) * tile_px, (ty + 1) * tile_px), outline=(15, 15, 15))
        draw.text((tx * tile_px + 6, ty * tile_px + 6), str(count), fill=(245, 245, 245))
    img.save(work_path("tile_layout.png"))
    return counts


def main() -> None:
    selected, mask, energy, smooth = build_mask()
    save_block_map(mask, work_path("selected_blocks_mask.png"), positive=(55, 220, 125), negative=(34, 34, 42))
    tile_counts = save_tile_layout(selected)
    border_ok = int(block_config.EXCLUDE_BORDER_BLOCKS) >= 2
    texture_ok = bool(block_config.USE_TEXTURE_ONLY)
    no_todo = not config_text_has_todo("block_config.py")
    accepted = len(selected) >= 450 and border_ok and texture_ok and no_todo
    write_json(
        work_path("block_mask.json"),
        {
            "selected_blocks": selected,
            "selected_count": len(selected),
            "tile_counts": tile_counts,
            "min_dct_energy": float(block_config.MIN_DCT_ENERGY),
            "max_smoothness": float(block_config.MAX_SMOOTHNESS),
            "exclude_border_blocks": int(block_config.EXCLUDE_BORDER_BLOCKS),
            "use_texture_only": bool(block_config.USE_TEXTURE_ONLY),
            "energy_mean_selected": float(np.mean([energy[b // GRID, b % GRID] for b in selected])) if selected else 0.0,
            "smooth_mean_selected": float(np.mean([smooth[b // GRID, b % GRID] for b in selected])) if selected else 0.0,
            "accepted": accepted,
        },
    )
    lines = [
        "DCT block mask report",
        f"Selected blocks: {len(selected)}",
        f"Border excluded: {'YES' if border_ok else 'NO'}",
        f"Texture filtering enabled: {'YES' if texture_ok else 'NO'}",
        f"TODO remaining in block_config.py: {'NO' if no_todo else 'YES'}",
    ]
    if accepted:
        lines.insert(0, "DCT block mask accepted")
    else:
        lines.append("Status: NOT ACCEPTED - tune block_config.py before running checkwork.")
    write_report(work_path("block_mask_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
