# ECC Design Notes

TODO: Explain the chosen ECC mode, parity bytes, repeat factor, and lane count.

