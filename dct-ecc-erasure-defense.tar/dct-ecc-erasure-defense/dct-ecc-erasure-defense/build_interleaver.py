from __future__ import annotations

import math

import numpy as np
from PIL import Image, ImageDraw

import ecc_config
import interleaver_config
from dct_ecc_helper import (
    BLOCK_SIZE,
    GRID,
    IMAGE_SIZE,
    TILE_GRID,
    block_tile,
    block_xy,
    config_text_has_todo,
    load_block_mask,
    load_payload,
    tile_center_pixels,
    work_path,
    write_json,
    write_report,
)


def distance(a: int, b: int) -> float:
    ax, ay = block_xy(a)
    bx, by = block_xy(b)
    return math.hypot((ax - bx) * BLOCK_SIZE, (ay - by) * BLOCK_SIZE)


def build_assignments(selected: list[int], encoded_len: int, repeat: int) -> list[dict]:
    if str(interleaver_config.INTERLEAVER_MODE) == "sequential":
        pool = selected[:]
    else:
        rng = np.random.default_rng(int(interleaver_config.SHUFFLE_SEED))
        stride_x = max(1, int(interleaver_config.STRIDE_X))
        stride_y = max(1, int(interleaver_config.STRIDE_Y))
        scored = []
        for block in selected:
            bx, by = block_xy(block)
            key = (bx * stride_x + by * stride_y + block_tile(block) * 17) % (GRID * GRID)
            scored.append((key, block))
        pool = [block for _, block in sorted(scored)]
        pool = list(rng.permutation(pool))
    needed = encoded_len * repeat
    if len(pool) < needed:
        raise SystemExit(f"Need {needed} selected blocks, but block_mask.json has {len(pool)}")

    assignments: list[dict] = []
    used: set[int] = set()
    min_tile_distance = int(interleaver_config.MIN_TILE_DISTANCE)
    for bit_index in range(encoded_len):
        chosen: list[int] = []
        for copy_index in range(repeat):
            start = (bit_index * repeat + copy_index * max(1, len(pool) // repeat)) % len(pool)
            candidate = None
            for offset in range(len(pool)):
                block = int(pool[(start + offset) % len(pool)])
                if block in used:
                    continue
                tile = block_tile(block)
                if min_tile_distance:
                    ok = True
                    for previous in chosen:
                        pa, pb = tile_center_pixels(block_tile(previous))
                        ca, cb = tile_center_pixels(tile)
                        if math.hypot(pa - ca, pb - cb) < min_tile_distance * (IMAGE_SIZE / TILE_GRID):
                            ok = False
                            break
                    if not ok:
                        continue
                candidate = block
                break
            if candidate is None:
                candidate = int(next(block for block in pool if block not in used))
            used.add(candidate)
            chosen.append(candidate)
            assignments.append(
                {
                    "bit_index": bit_index,
                    "copy_index": copy_index,
                    "block_index": candidate,
                    "tile": block_tile(candidate),
                }
            )
    return assignments


def save_interleaver_visual(assignments: list[dict]) -> None:
    img = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), (22, 24, 30))
    draw = ImageDraw.Draw(img)
    colors = [(235, 86, 70), (70, 150, 235), (88, 190, 115), (240, 190, 70), (180, 105, 220), (80, 210, 205)]
    for entry in assignments:
        bx, by = block_xy(int(entry["block_index"]))
        color = colors[int(entry["copy_index"]) % len(colors)]
        draw.rectangle((bx * BLOCK_SIZE, by * BLOCK_SIZE, (bx + 1) * BLOCK_SIZE - 1, (by + 1) * BLOCK_SIZE - 1), fill=color)
    tile_px = IMAGE_SIZE // TILE_GRID
    for i in range(TILE_GRID + 1):
        draw.line((i * tile_px, 0, i * tile_px, IMAGE_SIZE), fill=(10, 10, 10), width=1)
        draw.line((0, i * tile_px, IMAGE_SIZE, i * tile_px), fill=(10, 10, 10), width=1)
    img.save(work_path("interleaver_map.png"))


def main() -> None:
    payload = load_payload()
    if not payload:
        raise SystemExit("Run ecc_encode_message.py first.")
    selected = load_block_mask()
    if not selected:
        raise SystemExit("Run design_block_mask.py first.")
    encoded = payload["encoded_bits"]
    repeat = int(ecc_config.REPEAT_FACTOR)
    assignments = build_assignments(selected, len(encoded), repeat)
    save_interleaver_visual(assignments)
    copy_distances = []
    for bit_index in range(len(encoded)):
        blocks = [a["block_index"] for a in assignments if int(a["bit_index"]) == bit_index]
        for i in range(len(blocks)):
            for j in range(i + 1, len(blocks)):
                copy_distances.append(distance(int(blocks[i]), int(blocks[j])))
    tile_coverage = len({int(a["tile"]) for a in assignments}) / float(TILE_GRID * TILE_GRID)
    avg_distance = float(np.mean(copy_distances)) if copy_distances else 0.0
    no_todo = not config_text_has_todo("interleaver_config.py")
    accepted = (
        str(interleaver_config.INTERLEAVER_MODE) != "sequential"
        and avg_distance >= 80.0
        and tile_coverage >= 0.70
        and no_todo
    )
    write_json(
        work_path("interleaver_map.json"),
        {
            "assignments": assignments,
            "required_blocks": len(assignments),
            "average_bit_copy_distance": avg_distance,
            "tile_coverage": tile_coverage,
            "accepted": accepted,
        },
    )
    lines = [
        "Interleaver report",
        f"Interleaver mode: {interleaver_config.INTERLEAVER_MODE}",
        f"Required blocks: {len(assignments)}",
        f"Average bit-copy distance: {avg_distance:.2f} pixels",
        f"Tile coverage: {tile_coverage * 100.0:.2f}%",
        f"TODO remaining in interleaver_config.py: {'NO' if no_todo else 'YES'}",
    ]
    if accepted:
        lines.insert(0, "Interleaver map generated")
    else:
        lines.append("Status: NOT ACCEPTED - spread repeated bit copies across distant tiles.")
    write_report(work_path("interleaver_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

