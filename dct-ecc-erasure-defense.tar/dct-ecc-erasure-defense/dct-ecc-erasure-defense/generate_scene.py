from __future__ import annotations

from dct_ecc_helper import IMAGE_SIZE, generate_cover_scene, work_path, write_report


def main() -> None:
    generate_cover_scene(work_path("cover_scene.png"))
    lines = [
        "Cover scene generated",
        f"Image size: {IMAGE_SIZE}x{IMAGE_SIZE}",
        "Regions: smooth patch, textured stripe field, strong edges, crop-risk border zone",
        "Observation: textured and edge-rich areas are better DCT watermark carriers than flat areas.",
    ]
    write_report(work_path("scene_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

