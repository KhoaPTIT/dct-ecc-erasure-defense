# Recovery Memo

## Why raw extraction failed

TODO

## How interleaving reduced burst errors

TODO

## How erasure detection improved recovery

TODO

## Why some tiles were dropped

TODO

## Remaining weaknesses

TODO
