# DCT ECC-Erasure Defense Against Geometric Attacks

Lab name: `dct-ecc-erasure-defense`

This lab builds a DCT watermark that survives partial geometric damage without registration. You will tune block selection, ECC, interleaving, erasure detection, and weighted tile recovery.

The embedded message is:

```text
DCT ECC ERASURE DEFENSE B22DCAT164
```

Run the tasks in order. The starter configuration files intentionally do not pass.

Key rule: do not add registration, anchor points, keypoints, homography, inverse alignment, or brute-force rotation/scale search. The intended defense is robust-by-design.

