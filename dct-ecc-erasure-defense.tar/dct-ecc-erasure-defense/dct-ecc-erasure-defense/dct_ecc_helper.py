from __future__ import annotations

import json
import math
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

try:
    from scipy.fftpack import dct, idct
except ImportError:  # pragma: no cover - fallback is for lean containers
    dct = None
    idct = None


LAB_NAME = "dct-ecc-erasure-defense"
MESSAGE = "DCT ECC ERASURE DEFENSE B22DCAT164"
SEED = 1642026
IMAGE_SIZE = 512
BLOCK_SIZE = 8
GRID = IMAGE_SIZE // BLOCK_SIZE
TILE_GRID = 8
TILE_BLOCKS = GRID // TILE_GRID
COEFF_A = (3, 4)
COEFF_B = (4, 3)
_DCT_MATRIX: np.ndarray | None = None

try:
    RESAMPLE_NEAREST = Image.Resampling.NEAREST
    RESAMPLE_LANCZOS = Image.Resampling.LANCZOS
    RESAMPLE_BICUBIC = Image.Resampling.BICUBIC
except AttributeError:  # Pillow < 9.1 in older Labtainer base images
    RESAMPLE_NEAREST = Image.NEAREST
    RESAMPLE_LANCZOS = Image.LANCZOS
    RESAMPLE_BICUBIC = Image.BICUBIC


def script_dir() -> Path:
    return Path(__file__).resolve().parent


def work_path(name: str) -> Path:
    return script_dir() / name


def write_report(path: str | Path, lines: list[str]) -> None:
    Path(path).write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_json(path: str | Path, data: dict) -> None:
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def read_json(path: str | Path, default: dict | None = None) -> dict:
    p = Path(path)
    if not p.exists():
        return default or {}
    return json.loads(p.read_text(encoding="utf-8"))


def terminal_text(text: str) -> str:
    return text.encode("ascii", errors="replace").decode("ascii")


def message_bits(message: str = MESSAGE) -> list[int]:
    bits: list[int] = []
    for byte in message.encode("ascii"):
        for shift in range(7, -1, -1):
            bits.append((byte >> shift) & 1)
    return bits


def bits_to_message(bits: list[int]) -> str:
    out = bytearray()
    usable = len(bits) - (len(bits) % 8)
    for i in range(0, usable, 8):
        value = 0
        for bit in bits[i : i + 8]:
            value = (value << 1) | int(bit)
        out.append(value)
    return out.decode("ascii", errors="replace")


def bit_error_rate(expected: list[int], recovered: list[int]) -> float:
    if not expected:
        return 0.0
    n = min(len(expected), len(recovered))
    errors = sum(int(expected[i]) != int(recovered[i]) for i in range(n))
    errors += abs(len(expected) - len(recovered))
    return errors / len(expected)


def dct_matrix() -> np.ndarray:
    global _DCT_MATRIX
    if _DCT_MATRIX is not None:
        return _DCT_MATRIX
    n = BLOCK_SIZE
    mat = np.zeros((n, n), dtype=np.float64)
    for k in range(n):
        scale = math.sqrt(1.0 / n) if k == 0 else math.sqrt(2.0 / n)
        for i in range(n):
            mat[k, i] = scale * math.cos(math.pi * (2 * i + 1) * k / (2 * n))
    _DCT_MATRIX = mat
    return mat


def dct2(block: np.ndarray) -> np.ndarray:
    if dct is not None:
        return dct(dct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat @ block @ mat.T


def idct2(block: np.ndarray) -> np.ndarray:
    if idct is not None:
        return idct(idct(block.T, norm="ortho").T, norm="ortho")
    mat = dct_matrix()
    return mat.T @ block @ mat


def load_rgb(path: str | Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("RGB"), dtype=np.uint8)


def load_gray(path: str | Path) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float64)


def save_gray(array: np.ndarray, path: str | Path) -> None:
    clipped = np.clip(np.rint(array), 0, 255).astype(np.uint8)
    Image.fromarray(clipped, mode="L").convert("RGB").save(path)


def save_rgb(array: np.ndarray, path: str | Path) -> None:
    Image.fromarray(np.clip(array, 0, 255).astype(np.uint8), mode="RGB").save(path)


def psnr(a: np.ndarray, b: np.ndarray) -> float:
    mse = np.mean((a.astype(np.float64) - b.astype(np.float64)) ** 2)
    if mse <= 1e-12:
        return float("inf")
    return 20.0 * math.log10(255.0 / math.sqrt(mse))


def block_xy(block_index: int) -> tuple[int, int]:
    return block_index % GRID, block_index // GRID


def block_index_from_xy(bx: int, by: int) -> int:
    return by * GRID + bx


def block_tile(block_index: int) -> int:
    bx, by = block_xy(block_index)
    tx = min(TILE_GRID - 1, bx // TILE_BLOCKS)
    ty = min(TILE_GRID - 1, by // TILE_BLOCKS)
    return ty * TILE_GRID + tx


def tile_xy(tile: int) -> tuple[int, int]:
    return tile % TILE_GRID, tile // TILE_GRID


def tile_center_pixels(tile: int) -> tuple[float, float]:
    tx, ty = tile_xy(tile)
    return ((tx + 0.5) * IMAGE_SIZE / TILE_GRID, (ty + 0.5) * IMAGE_SIZE / TILE_GRID)


def calculate_block_metrics(gray: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    energy = np.zeros((GRID, GRID), dtype=np.float64)
    smooth = np.zeros((GRID, GRID), dtype=np.float64)
    for by in range(GRID):
        for bx in range(GRID):
            y = by * BLOCK_SIZE
            x = bx * BLOCK_SIZE
            block = gray[y : y + BLOCK_SIZE, x : x + BLOCK_SIZE] - 128.0
            coeff = dct2(block)
            mid = coeff[2:6, 2:6].copy()
            mid[1, 2] = 0.0
            mid[2, 1] = 0.0
            energy[by, bx] = float(np.mean(np.abs(mid)) * 3.5)
            smooth[by, bx] = float(np.std(block) * 0.8)
    return energy, smooth


def normalize_to_u8(values: np.ndarray) -> np.ndarray:
    v = values.astype(np.float64)
    lo, hi = np.percentile(v, [2, 98])
    if hi <= lo:
        return np.zeros_like(v, dtype=np.uint8)
    out = (np.clip(v, lo, hi) - lo) / (hi - lo)
    return np.rint(out * 255).astype(np.uint8)


def color_heatmap(values: np.ndarray) -> np.ndarray:
    base = normalize_to_u8(values)
    r = base
    g = np.clip(255 - np.abs(base.astype(int) - 128) * 2, 0, 255).astype(np.uint8)
    b = 255 - base
    small = np.dstack([r, g, b])
    return np.asarray(Image.fromarray(small, mode="RGB").resize((IMAGE_SIZE, IMAGE_SIZE), RESAMPLE_NEAREST))


def draw_label(draw: ImageDraw.ImageDraw, xy: tuple[int, int], text: str, fill=(255, 255, 255)) -> None:
    draw.text(xy, text, fill=fill, font=ImageFont.load_default())


def ensure_cover() -> Path:
    path = work_path("cover_scene.png")
    if not path.exists():
        generate_cover_scene(path)
    return path


def generate_cover_scene(path: str | Path) -> None:
    size = IMAGE_SIZE
    y, x = np.mgrid[0:size, 0:size]
    gradient = 55 + 85 * (x / (size - 1)) + 55 * (y / (size - 1))
    texture = 16 * np.sin(x / 6.0) + 11 * np.cos(y / 9.0) + 9 * np.sin((x + 2 * y) / 13.0)
    rng = np.random.default_rng(SEED)
    grain = rng.normal(0, 5, (size, size))
    base = np.clip(gradient + texture + grain, 0, 255)

    rgb = np.zeros((size, size, 3), dtype=np.uint8)
    rgb[..., 0] = np.clip(base + 18 * np.sin(y / 23.0), 0, 255)
    rgb[..., 1] = np.clip(base + 25 * np.cos(x / 31.0), 0, 255)
    rgb[..., 2] = np.clip(230 - base / 2 + 22 * np.sin((x - y) / 17.0), 0, 255)
    img = Image.fromarray(rgb, mode="RGB")
    draw = ImageDraw.Draw(img)

    draw.rectangle((24, 24, 488, 488), outline=(238, 238, 238), width=4)
    draw.rectangle((44, 52, 178, 192), fill=(88, 90, 92), outline=(245, 245, 245), width=2)
    draw.rectangle((202, 46, 468, 160), fill=(180, 190, 204), outline=(30, 40, 55), width=3)
    for i in range(30):
        yy = 210 + i * 7
        draw.line((36, yy, 474, yy - 62), fill=(250, 230, 65), width=2)
    draw.ellipse((300, 250, 454, 408), outline=(40, 115, 205), width=6)
    draw.polygon([(60, 350), (145, 285), (232, 362), (156, 440)], fill=(35, 135, 100), outline=(235, 245, 235))
    draw.line((18, 472, 500, 410), fill=(35, 35, 35), width=5)
    draw.text((70, 92), "SMOOTH", fill=(248, 248, 248), font=ImageFont.load_default())
    draw.text((276, 92), "CROP RISK", fill=(30, 30, 30), font=ImageFont.load_default())
    draw.text((82, 420), "TEXTURE / EDGES FOR DCT WATERMARK", fill=(255, 255, 255), font=ImageFont.load_default())
    img.save(path)


def load_block_mask() -> list[int]:
    data = read_json(work_path("block_mask.json"), {})
    return [int(x) for x in data.get("selected_blocks", [])]


def load_payload() -> dict:
    return read_json(work_path("encoded_payload.json"), {})


def load_interleaver() -> dict:
    return read_json(work_path("interleaver_map.json"), {})


def expected_encoded_bits() -> list[int]:
    payload = load_payload()
    return [int(x) for x in payload.get("encoded_bits", [])]


def expected_message_bits() -> list[int]:
    return message_bits(MESSAGE)


def config_text_has_todo(name: str) -> bool:
    text = work_path(name).read_text(encoding="utf-8") if work_path(name).exists() else ""
    return "TODO" in text


def report_has_marker(name: str, marker: str) -> bool:
    text = work_path(name).read_text(encoding="utf-8") if work_path(name).exists() else ""
    return marker in text


def parse_report_metric(text: str, label: str, default: float = 0.0) -> float:
    pattern = re.escape(label) + r"\s*[:=]\s*([0-9.]+)"
    match = re.search(pattern, text)
    return float(match.group(1)) if match else default


def text_of(name: str) -> str:
    path = work_path(name)
    return path.read_text(encoding="utf-8") if path.exists() else ""


def load_config_module(name: str):
    import importlib

    if name in importlib.sys.modules:
        return importlib.reload(importlib.import_module(name))
    return importlib.import_module(name)


def add_visual_title(image: Image.Image, title: str) -> Image.Image:
    canvas = Image.new("RGB", (image.width, image.height + 24), (18, 20, 24))
    canvas.paste(image.convert("RGB"), (0, 24))
    draw = ImageDraw.Draw(canvas)
    draw.text((8, 7), title, fill=(245, 245, 245), font=ImageFont.load_default())
    return canvas


def make_contact_sheet(items: list[tuple[str, str]], out_path: str | Path, cell: int = 220) -> None:
    thumbs: list[Image.Image] = []
    for title, filename in items:
        p = work_path(filename)
        if p.exists():
            img = Image.open(p).convert("RGB").resize((cell, cell), RESAMPLE_LANCZOS)
        else:
            img = Image.new("RGB", (cell, cell), (65, 65, 65))
            draw = ImageDraw.Draw(img)
            draw.text((12, 96), "missing", fill=(255, 255, 255), font=ImageFont.load_default())
        thumbs.append(add_visual_title(img, title))
    cols = 5
    rows = math.ceil(len(thumbs) / cols)
    sheet = Image.new("RGB", (cols * cell, rows * (cell + 24)), (18, 20, 24))
    for i, img in enumerate(thumbs):
        x = (i % cols) * cell
        y = (i // cols) * (cell + 24)
        sheet.paste(img, (x, y))
    sheet.save(out_path)


def parity_bits(bits: list[int], parity_bytes: int) -> list[int]:
    out: list[int] = []
    if parity_bytes <= 0:
        return out
    for byte_index in range(parity_bytes):
        value = 0
        for bit_index, bit in enumerate(bits):
            if ((bit_index + 1) * (byte_index + 3) + SEED) % (parity_bytes + 5) in {0, 3, 7}:
                value ^= int(bit)
        for shift in range(7, -1, -1):
            out.append((value >> shift) & 1)
    return out


def image_to_damage_mask(name: str) -> tuple[np.ndarray, str]:
    meta = read_json(work_path("attack_metadata.json"), {}).get(name, {})
    damaged = np.zeros(GRID * GRID, dtype=bool)
    for block in meta.get("damaged_blocks", []):
        if 0 <= int(block) < GRID * GRID:
            damaged[int(block)] = True
    return damaged, str(meta.get("mode", "unknown"))


def save_block_map(values: np.ndarray, path: str | Path, positive=(230, 60, 60), negative=(35, 70, 100)) -> None:
    if values.ndim == 1:
        values = values.reshape((GRID, GRID))
    img = np.zeros((GRID, GRID, 3), dtype=np.uint8)
    v = np.clip(values.astype(np.float64), 0, 1)
    for c in range(3):
        img[..., c] = np.rint(negative[c] * (1 - v) + positive[c] * v).astype(np.uint8)
    Image.fromarray(img, mode="RGB").resize((IMAGE_SIZE, IMAGE_SIZE), RESAMPLE_NEAREST).save(path)


def save_tile_map(tile_values: dict[int, float], path: str | Path) -> None:
    small = np.zeros((TILE_GRID, TILE_GRID), dtype=np.float64)
    for tile, value in tile_values.items():
        tx, ty = tile_xy(int(tile))
        small[ty, tx] = float(value)
    image = Image.fromarray(color_heatmap(small), mode="RGB")
    draw = ImageDraw.Draw(image)
    tile_px = IMAGE_SIZE // TILE_GRID
    for i in range(TILE_GRID + 1):
        draw.line((i * tile_px, 0, i * tile_px, IMAGE_SIZE), fill=(20, 20, 20), width=1)
        draw.line((0, i * tile_px, IMAGE_SIZE, i * tile_px), fill=(20, 20, 20), width=1)
    image.save(path)
