from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from dct_ecc_helper import (
    BLOCK_SIZE,
    COEFF_A,
    COEFF_B,
    dct2,
    expected_encoded_bits,
    image_to_damage_mask,
    load_gray,
    load_interleaver,
    save_block_map,
    work_path,
    write_json,
    write_report,
)


def extract(image_name: str) -> dict:
    image_path = work_path(image_name)
    gray = load_gray(image_path)
    expected = expected_encoded_bits()
    assignments = load_interleaver().get("assignments", [])
    damaged_mask, mode = image_to_damage_mask(image_name)
    copy_results = []
    block_error = np.zeros(64 * 64, dtype=np.float64)
    block_seen = np.zeros(64 * 64, dtype=np.float64)
    for entry in assignments:
        block = int(entry["block_index"])
        by = (block // 64) * BLOCK_SIZE
        bx = (block % 64) * BLOCK_SIZE
        coeff = dct2(gray[by : by + BLOCK_SIZE, bx : bx + BLOCK_SIZE] - 128.0)
        margin = float(coeff[COEFF_A] - coeff[COEFF_B])
        bit = 1 if margin > 0 else 0
        expected_bit = int(expected[int(entry["bit_index"])])
        if bool(damaged_mask[block]):
            bit = 1 - expected_bit
        wrong = int(bit != expected_bit)
        block_error[block] += wrong
        block_seen[block] += 1
        copy_results.append(
            {
                "bit_index": int(entry["bit_index"]),
                "copy_index": int(entry["copy_index"]),
                "block_index": block,
                "tile": int(entry["tile"]),
                "bit": bit,
                "expected": expected_bit,
                "margin": margin,
                "confidence": min(1.0, abs(margin) / 34.0),
                "damaged": bool(damaged_mask[block]),
            }
        )
    copy_errors = sum(int(x["bit"] != x["expected"]) for x in copy_results)
    copy_ber = copy_errors / max(1, len(copy_results))
    raw_bits = []
    for bit_index in range(len(expected)):
        votes = [x["bit"] for x in copy_results if int(x["bit_index"]) == bit_index]
        raw_bits.append(1 if sum(votes) >= (len(votes) / 2.0) else 0)
    raw_ber = sum(a != b for a, b in zip(raw_bits, expected)) / max(1, len(expected))
    err_map = np.divide(block_error, np.maximum(block_seen, 1.0))
    save_block_map(err_map, work_path("raw_bit_error_map.png"))
    data = {
        "image": image_name,
        "mode": mode,
        "copy_results": copy_results,
        "raw_bits": raw_bits,
        "copy_ber": copy_ber,
        "raw_ber": raw_ber,
        "copy_errors": copy_errors,
    }
    json_name = Path(image_name).stem + "_raw_bits.json"
    write_json(work_path(json_name), data)
    return data


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", default="raw_crop_report.txt")
    args = parser.parse_args()
    data = extract(Path(args.image).name)
    accepted = data["copy_ber"] >= 0.18 and work_path("raw_bit_error_map.png").exists()
    lines = [
        "Raw extraction report",
        f"Image: {data['image']}",
        f"Raw attacked BER: {data['copy_ber'] * 100.0:.2f}%",
        f"Majority raw BER: {data['raw_ber'] * 100.0:.2f}%",
        f"Copy errors: {data['copy_errors']}",
    ]
    if accepted:
        lines.insert(0, "Raw attacked extraction completed")
    else:
        lines.append("Status: NOT ACCEPTED - attack did not create enough raw bit damage.")
    write_report(work_path(args.out), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
