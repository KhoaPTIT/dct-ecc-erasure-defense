from __future__ import annotations

from dct_ecc_helper import work_path, write_report


REQUIRED_HEADINGS = [
    "## Why raw extraction failed",
    "## How interleaving reduced burst errors",
    "## How erasure detection improved recovery",
    "## Why some tiles were dropped",
    "## Remaining weaknesses",
]

REQUIRED_TERMS = [
    "Raw BER",
    "Corrected BER",
    "Erasure rate",
    "Tile survival rate",
    "tile",
    "weak",
]


def main() -> None:
    path = work_path("RECOVERY_MEMO.md")
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    missing = [h for h in REQUIRED_HEADINGS if h not in text]
    missing_terms = [t for t in REQUIRED_TERMS if t.lower() not in text.lower()]
    has_todo = "TODO" in text
    accepted = not missing and not missing_terms and not has_todo
    lines = [
        "Memo validation report",
        f"Missing headings: {', '.join(missing) if missing else 'none'}",
        f"Missing required concepts: {', '.join(missing_terms) if missing_terms else 'none'}",
        f"TODO remaining: {'YES' if has_todo else 'NO'}",
    ]
    if accepted:
        lines.insert(0, "ECC erasure defense memo accepted")
    else:
        lines.append("Status: NOT ACCEPTED - revise RECOVERY_MEMO.md.")
    write_report(work_path("memo_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

