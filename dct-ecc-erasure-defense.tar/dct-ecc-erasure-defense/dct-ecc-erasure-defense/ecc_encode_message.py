from __future__ import annotations

from PIL import Image, ImageDraw

import ecc_config
from dct_ecc_helper import MESSAGE, config_text_has_todo, message_bits, parity_bits, work_path, write_json, write_report


def save_syndrome_table(bits: list[int], parity: list[int]) -> None:
    width, height = 640, 360
    img = Image.new("RGB", (width, height), (245, 247, 250))
    draw = ImageDraw.Draw(img)
    draw.text((20, 18), "ECC syndrome / parity overview", fill=(20, 25, 35))
    cell = 10
    start_x, start_y = 24, 58
    all_bits = bits + parity
    for i, bit in enumerate(all_bits[:320]):
        x = start_x + (i % 64) * cell
        y = start_y + (i // 64) * cell
        fill = (45, 105, 210) if bit else (225, 230, 238)
        if i >= len(bits):
            fill = (230, 135, 35) if bit else (250, 215, 170)
        draw.rectangle((x, y, x + 8, y + 8), fill=fill)
    draw.text((24, 314), "blue = message bits, orange = parity bits", fill=(40, 40, 40))
    img.save(work_path("ecc_syndrome_table.png"))


def main() -> None:
    msg_bits = message_bits(MESSAGE)
    parity = parity_bits(msg_bits, int(ecc_config.PARITY_BYTES))
    encoded = msg_bits + parity if ecc_config.ECC_MODE != "none" else msg_bits
    lane_count = max(1, int(ecc_config.LANE_COUNT))
    lanes = [[] for _ in range(lane_count)]
    for i, bit in enumerate(encoded):
        lanes[i % lane_count].append(int(bit))
    save_syndrome_table(msg_bits, parity)
    no_todo = not config_text_has_todo("ecc_config.py")
    accepted = (
        str(ecc_config.ECC_MODE) != "none"
        and int(ecc_config.PARITY_BYTES) >= 8
        and int(ecc_config.REPEAT_FACTOR) >= 3
        and int(ecc_config.LANE_COUNT) >= 4
        and no_todo
    )
    write_json(
        work_path("encoded_payload.json"),
        {
            "message": MESSAGE,
            "message_bits": msg_bits,
            "encoded_bits": encoded,
            "parity_bits": parity,
            "ecc_mode": str(ecc_config.ECC_MODE),
            "parity_bytes": int(ecc_config.PARITY_BYTES),
            "repeat_factor": int(ecc_config.REPEAT_FACTOR),
            "lane_count": int(ecc_config.LANE_COUNT),
            "lane_lengths": [len(x) for x in lanes],
            "accepted": accepted,
        },
    )
    lines = [
        "ECC design report",
        f"Message: {MESSAGE}",
        f"ECC mode: {ecc_config.ECC_MODE}",
        f"Message bits: {len(msg_bits)}",
        f"Parity bytes: {int(ecc_config.PARITY_BYTES)}",
        f"Encoded bits: {len(encoded)}",
        f"Repeat factor: {int(ecc_config.REPEAT_FACTOR)}",
        f"Lane count: {int(ecc_config.LANE_COUNT)}",
        f"TODO remaining in ecc_config.py: {'NO' if no_todo else 'YES'}",
    ]
    if accepted:
        lines.insert(0, "ECC payload encoded")
    else:
        lines.append("Status: NOT ACCEPTED - choose stronger ECC settings.")
    work_path("encoded_payload.bin").write_bytes(bytes(encoded))
    write_report(work_path("ecc_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

