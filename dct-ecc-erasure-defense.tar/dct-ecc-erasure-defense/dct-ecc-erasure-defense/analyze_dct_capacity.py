from __future__ import annotations

import numpy as np
from PIL import Image

from dct_ecc_helper import (
    calculate_block_metrics,
    color_heatmap,
    ensure_cover,
    load_gray,
    work_path,
    write_json,
    write_report,
)


def main() -> None:
    cover = ensure_cover()
    gray = load_gray(cover)
    energy, smooth = calculate_block_metrics(gray)
    Image.fromarray(color_heatmap(energy), mode="RGB").save(work_path("dct_energy_map.png"))
    np.savez(work_path("dct_capacity_metrics.npz"), energy=energy, smooth=smooth)
    metrics = {
        "energy_mean": float(energy.mean()),
        "energy_p50": float(np.percentile(energy, 50)),
        "energy_p75": float(np.percentile(energy, 75)),
        "smoothness_mean": float(smooth.mean()),
        "texture_blocks_22": int((energy >= 22.0).sum()),
    }
    write_json(work_path("dct_capacity_metrics.json"), metrics)
    lines = [
        "DCT capacity analysis completed",
        f"Mean DCT energy: {metrics['energy_mean']:.2f}",
        f"Median DCT energy: {metrics['energy_p50']:.2f}",
        f"75th percentile DCT energy: {metrics['energy_p75']:.2f}",
        f"Blocks with energy >= 22.0: {metrics['texture_blocks_22']}",
        "Observation: low-energy smooth blocks are visually fragile and should not be used first.",
    ]
    write_report(work_path("dct_capacity_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
