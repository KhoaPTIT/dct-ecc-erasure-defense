from __future__ import annotations

from dct_ecc_helper import make_contact_sheet, work_path, write_report


def main() -> None:
    items = [
        ("cover", "cover_scene.png"),
        ("dct energy", "dct_energy_map.png"),
        ("selected blocks", "selected_blocks_mask.png"),
        ("interleaver", "interleaver_map.png"),
        ("stego", "stego_ecc.png"),
        ("crop shift", "attack_crop_shift.png"),
        ("rotation scale", "attack_rotation_scale.png"),
        ("raw errors", "raw_bit_error_map.png"),
        ("erasures", "erasure_confidence_map.png"),
        ("tile survival", "tile_survival_map.png"),
    ]
    make_contact_sheet(items, work_path("recovery_contact_sheet.png"), cell=210)
    lines = [
        "Visual damage evidence completed",
        "Contact sheet: recovery_contact_sheet.png",
        "Panels: cover, DCT energy, selected mask, interleaver, stego, attacks, raw errors, erasures, tile survival.",
    ]
    write_report(work_path("visual_report.txt"), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

