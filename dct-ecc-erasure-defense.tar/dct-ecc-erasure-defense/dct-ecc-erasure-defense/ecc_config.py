# TODO: choose a stronger ECC setup
ECC_MODE = "none"
PARITY_BYTES = 0
REPEAT_FACTOR = 1
LANE_COUNT = 1
