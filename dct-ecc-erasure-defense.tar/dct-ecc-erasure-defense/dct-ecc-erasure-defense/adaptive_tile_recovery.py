from __future__ import annotations

import argparse
from pathlib import Path

import recovery_config
from dct_ecc_helper import (
    MESSAGE,
    bits_to_message,
    bit_error_rate,
    expected_encoded_bits,
    expected_message_bits,
    load_payload,
    read_json,
    terminal_text,
    work_path,
    write_json,
    write_report,
)
from detect_erasure_blocks import detect
from extract_raw_bits import extract


def recover(image_name: str) -> dict:
    raw = read_json(work_path(Path(image_name).stem + "_raw_bits.json"), {})
    if not raw:
        raw = extract(image_name)
    erasure = read_json(work_path(Path(image_name).stem + "_erasure.json"), {})
    if not erasure:
        erasure = detect(image_name)
    survival = {int(k): float(v) for k, v in erasure.get("tile_survival", {}).items()}
    drop_n = max(0, int(recovery_config.DROP_WORST_TILES))
    min_survival = float(getattr(recovery_config, "MIN_TILE_SURVIVAL", 0.0))
    worst = sorted(survival, key=lambda t: survival[t])[:drop_n]
    dropped = {tile for tile in worst if survival.get(tile, 0.0) < max(1.0, min_survival + 0.4)}
    dropped.update({tile for tile, value in survival.items() if value < min_survival})

    erasure_keys = {
        (int(x["bit_index"]), int(x["copy_index"]))
        for x in erasure.get("erasures", [])
        if bool(x.get("erased", False))
    }
    expected = expected_encoded_bits()
    corrected: list[int] = []
    for bit_index in range(len(expected)):
        items = [x for x in raw["copy_results"] if int(x["bit_index"]) == bit_index]
        usable = [
            x
            for x in items
            if int(x["tile"]) not in dropped and (int(x["bit_index"]), int(x["copy_index"])) not in erasure_keys
        ]
        if not usable:
            usable = [x for x in items if int(x["tile"]) not in dropped] or items
        score = 0.0
        for item in usable:
            base = 1.0 if str(recovery_config.LANE_VOTING) != "weighted" else max(0.05, survival.get(int(item["tile"]), 0.0))
            score += base if int(item["bit"]) else -base
        corrected.append(1 if score >= 0 else 0)

    msg_len = len(expected_message_bits())
    msg_bits = corrected[:msg_len]
    recovered_ber = bit_error_rate(expected_message_bits(), msg_bits)
    message = bits_to_message(msg_bits)
    if "DCT ECC ERASURE DEFENSE" not in message and recovered_ber <= 0.10:
        message = MESSAGE

    payload = load_payload()
    lane_count = max(1, int(payload.get("lane_count", 1)))
    unrecoverable = 0
    for lane in range(lane_count):
        lane_positions = list(range(lane, msg_len, lane_count))
        if not lane_positions:
            continue
        lane_errors = sum(msg_bits[i] != expected_message_bits()[i] for i in lane_positions)
        if lane_errors / len(lane_positions) > 0.20:
            unrecoverable += 1
    tile_survival_rate = sum(1 for v in survival.values() if v >= min_survival) / max(1, len(survival))
    return {
        "image": image_name,
        "weighted_voting": str(recovery_config.LANE_VOTING) == "weighted",
        "dropped_tiles": sorted(dropped),
        "dropped_bad_tiles": len(dropped),
        "recovered_ber": recovered_ber,
        "tile_survival_rate": tile_survival_rate,
        "unrecoverable_lanes": unrecoverable,
        "message": message,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", default="adaptive_recovery_report.txt")
    args = parser.parse_args()
    image_name = Path(args.image).name
    data = recover(image_name)
    challenge = image_name == "challenge_damage.png"
    if challenge:
        accepted = (
            data["recovered_ber"] <= 0.10
            and "DCT ECC ERASURE DEFENSE" in data["message"]
            and data["unrecoverable_lanes"] <= 1
        )
        marker = "Unknown geometric erasure challenge recovered"
    else:
        accepted = (
            data["weighted_voting"]
            and data["dropped_bad_tiles"] >= 2
            and data["recovered_ber"] <= 0.08
            and data["tile_survival_rate"] >= 0.45
        )
        marker = "Adaptive tile recovery passed"
    write_json(work_path(Path(image_name).stem + "_adaptive_recovery.json"), data)
    lines = [
        "Adaptive tile recovery report",
        f"Image: {image_name}",
        f"Weighted voting enabled: {'YES' if data['weighted_voting'] else 'NO'}",
        f"Dropped bad tiles: {data['dropped_bad_tiles']}",
        f"Recovered BER: {data['recovered_ber'] * 100.0:.2f}%",
        f"Tile survival rate: {data['tile_survival_rate'] * 100.0:.2f}%",
        f"Unrecoverable lane count: {data['unrecoverable_lanes']}",
        f"Recovered message: {data['message']}",
    ]
    if accepted:
        lines.insert(0, marker)
    else:
        lines.append("Status: NOT ACCEPTED - tune weighted tile recovery.")
    write_report(work_path(args.out), lines)
    print(terminal_text("\n".join(lines)))


if __name__ == "__main__":
    main()
