from __future__ import annotations

import re

from dct_ecc_helper import read_json, terminal_text, text_of, work_path, write_report


def metric_from_text(name: str, label: str, default: str = "n/a") -> str:
    text = text_of(name)
    match = re.search(re.escape(label) + r"\s*:\s*([^\n]+)", text)
    return match.group(1).strip() if match else default


def main() -> None:
    embed = read_json(work_path("embed_metrics.json"), {})
    crop_raw = metric_from_text("raw_crop_report.txt", "Raw attacked BER")
    rot_raw = metric_from_text("raw_rot_report.txt", "Raw attacked BER")
    erasure = metric_from_text("erasure_report.txt", "Erasure rate")
    corrected = metric_from_text("ecc_decode_report.txt", "Corrected BER")
    adaptive = metric_from_text("adaptive_recovery_report.txt", "Recovered BER")
    challenge = metric_from_text("challenge_recovery_report.txt", "Recovered BER")
    corrections = metric_from_text("ecc_decode_report.txt", "ECC corrected bits")
    survival = metric_from_text("adaptive_recovery_report.txt", "Tile survival rate")
    message = metric_from_text("challenge_recovery_report.txt", "Recovered message", metric_from_text("ecc_decode_report.txt", "Recovered message"))
    markers = [
        ("task1_scene", "scene_report.txt", "Cover scene generated"),
        ("task2_dct_capacity", "dct_capacity_report.txt", "DCT capacity analysis completed"),
        ("task3_block_mask", "block_mask_report.txt", "DCT block mask accepted"),
        ("task4_ecc_design", "ecc_report.txt", "ECC payload encoded"),
        ("task5_interleaver", "interleaver_report.txt", "Interleaver map generated"),
        ("task6_embed_ecc", "embed_ecc_report.txt", "ECC DCT watermark embedded"),
        ("task7_geometric_damage", "crop_shift_attack_report.txt", "Geometric damage attacks generated"),
        ("task8_raw_extract", "raw_crop_report.txt", "Raw attacked extraction completed"),
        ("task9_erasure_detection", "erasure_report.txt", "Erasure blocks detected"),
        ("task10_ecc_decode", "ecc_decode_report.txt", "ECC erasure decoding completed"),
        ("task11_adaptive_recovery", "adaptive_recovery_report.txt", "Adaptive tile recovery passed"),
        ("task12_challenge_recovery", "challenge_recovery_report.txt", "Unknown geometric erasure challenge recovered"),
        ("task13_visual_evidence", "visual_report.txt", "Visual damage evidence completed"),
        ("task14_memo", "memo_report.txt", "ECC erasure defense memo accepted"),
    ]
    ready = all(marker in text_of(report) for _, report, marker in markers)
    lines = [
        "DCT ECC erasure defense summary completed" if ready else "DCT ECC erasure defense summary incomplete",
        f"PSNR: {float(embed.get('psnr', 0.0)):.2f} dB",
        f"Clean BER: {float(embed.get('clean_ber', 1.0)) * 100.0:.2f}%",
        f"Raw crop-shift BER: {crop_raw}",
        f"Raw rotation-scale BER: {rot_raw}",
        f"Erasure rate: {erasure}",
        f"Corrected BER: {corrected}",
        f"Adaptive recovered BER: {adaptive}",
        f"Challenge recovered BER: {challenge}",
        f"ECC correction count: {corrections}",
        f"Tile survival rate: {survival}",
        f"Final recovered message: {message}",
    ]
    write_report(work_path("summary_report.txt"), lines)
    print(terminal_text("\n".join(lines)))


if __name__ == "__main__":
    main()
