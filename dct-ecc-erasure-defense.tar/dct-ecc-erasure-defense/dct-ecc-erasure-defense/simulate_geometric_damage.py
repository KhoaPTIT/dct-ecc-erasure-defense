from __future__ import annotations

import argparse

import numpy as np
from PIL import Image, ImageDraw

from dct_ecc_helper import (
    BLOCK_SIZE,
    GRID,
    IMAGE_SIZE,
    RESAMPLE_BICUBIC,
    block_index_from_xy,
    block_tile,
    load_interleaver,
    load_rgb,
    read_json,
    save_rgb,
    work_path,
    write_json,
    write_report,
)


def target_tiles(mode: str) -> set[int]:
    if mode == "crop_shift":
        return {0, 1, 2, 3, 8, 9, 10, 11, 16, 17, 18, 24, 25, 26, 32, 33, 40, 41, 48, 49, 50, 56, 57, 58, 59, 60, 61, 62}
    if mode == "rotate_scale":
        return {4, 5, 6, 7, 12, 13, 14, 15, 20, 21, 22, 23, 28, 29, 30, 31, 36, 37, 38, 45, 46, 53, 54, 55, 61, 62, 63}
    return {3, 4, 11, 12, 19, 20, 27, 28, 35, 44, 52, 60}


def corrupt_blocks(img: np.ndarray, tiles: set[int], severity: float) -> list[int]:
    rng = np.random.default_rng(164 + len(tiles))
    assignments = load_interleaver().get("assignments", [])
    selected_blocks = sorted({int(a["block_index"]) for a in assignments if int(a["tile"]) in tiles})
    damaged: list[int] = []
    for block in selected_blocks:
        if rng.random() > severity:
            continue
        bx = block % GRID
        by = block // GRID
        x = bx * BLOCK_SIZE
        y = by * BLOCK_SIZE
        fill = int(118 + ((bx * 13 + by * 7) % 22))
        img[y : y + BLOCK_SIZE, x : x + BLOCK_SIZE, :] = fill
        damaged.append(block)
    return damaged


def draw_attack_marks(img: np.ndarray, mode: str, crop: int, dx: int, dy: int, angle: float, scale: float) -> np.ndarray:
    pil = Image.fromarray(img, mode="RGB")
    draw = ImageDraw.Draw(pil)
    if mode == "crop_shift":
        draw.rectangle((0, 0, IMAGE_SIZE - 1, crop), fill=(125, 125, 125))
        draw.rectangle((0, 0, crop, IMAGE_SIZE - 1), fill=(125, 125, 125))
        draw.rectangle((IMAGE_SIZE - crop, 0, IMAGE_SIZE - 1, IMAGE_SIZE - 1), outline=(85, 85, 85), width=3)
        draw.text((24, 24), f"crop {crop}px shift {dx},{dy}", fill=(20, 20, 20))
    elif mode == "rotate_scale":
        overlay = pil.rotate(angle, resample=RESAMPLE_BICUBIC, center=(IMAGE_SIZE // 2, IMAGE_SIZE // 2))
        w = int(IMAGE_SIZE * scale)
        resized = overlay.resize((w, w), RESAMPLE_BICUBIC)
        canvas = Image.new("RGB", (IMAGE_SIZE, IMAGE_SIZE), (132, 132, 132))
        canvas.paste(resized, ((IMAGE_SIZE - w) // 2, (IMAGE_SIZE - w) // 2))
        pil = Image.blend(pil, canvas, 0.22)
        draw = ImageDraw.Draw(pil)
        draw.text((24, 24), f"local rotate {angle} scale {scale}", fill=(20, 20, 20))
    else:
        draw.rectangle((300, 30, 505, 250), fill=(128, 128, 128))
        draw.polygon([(30, 340), (210, 300), (230, 500), (40, 500)], fill=(120, 120, 120))
        draw.text((24, 24), "unknown geometric erasure challenge", fill=(20, 20, 20))
    return np.asarray(pil, dtype=np.uint8)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["crop_shift", "rotate_scale", "challenge"], required=True)
    parser.add_argument("--crop", type=int, default=18)
    parser.add_argument("--dx", type=int, default=9)
    parser.add_argument("--dy", type=int, default=-6)
    parser.add_argument("--angle", type=float, default=4.0)
    parser.add_argument("--scale", type=float, default=0.94)
    args = parser.parse_args()

    stego = work_path("stego_ecc.png")
    if not stego.exists():
        raise SystemExit("Run embed_ecc_watermark.py first.")
    img = load_rgb(stego).copy()
    severity = 0.98 if args.mode == "crop_shift" else 0.94 if args.mode == "rotate_scale" else 0.72
    tiles = target_tiles(args.mode)
    damaged = corrupt_blocks(img, tiles, severity)
    img = draw_attack_marks(img, args.mode, args.crop, args.dx, args.dy, args.angle, args.scale)

    if args.mode == "crop_shift":
        out_name = "attack_crop_shift.png"
        report_name = "crop_shift_attack_report.txt"
    elif args.mode == "rotate_scale":
        out_name = "attack_rotation_scale.png"
        report_name = "rotation_scale_attack_report.txt"
    else:
        out_name = "challenge_damage.png"
        report_name = "challenge_public_report.txt"
    save_rgb(img, work_path(out_name))

    meta = read_json(work_path("attack_metadata.json"), {})
    meta[out_name] = {
        "mode": args.mode,
        "damaged_blocks": damaged,
        "damaged_tiles": sorted(tiles),
        "severity": severity,
    }
    write_json(work_path("attack_metadata.json"), meta)

    marker = "Geometric damage attacks generated" if args.mode in {"crop_shift", "rotate_scale"} else "Unknown challenge damage generated"
    lines = [
        marker,
        f"Mode: {args.mode}",
        f"Damaged tiles: {len(tiles)}",
        f"Damaged assigned blocks: {len(damaged)}",
        f"Output image: {out_name}",
    ]
    write_report(work_path(report_name), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
