# Block Selection Notes

TODO: Explain which DCT blocks should carry the watermark and why border blocks are risky.

