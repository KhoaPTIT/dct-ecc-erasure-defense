from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

import recovery_config
from dct_ecc_helper import (
    config_text_has_todo,
    read_json,
    save_block_map,
    save_tile_map,
    work_path,
    write_json,
    write_report,
)
from extract_raw_bits import extract


def raw_json_name(image_name: str) -> str:
    return Path(image_name).stem + "_raw_bits.json"


def detect(image_name: str) -> dict:
    raw_path = work_path(raw_json_name(image_name))
    raw = read_json(raw_path, {})
    if not raw:
        raw = extract(image_name)
    mode_enabled = str(recovery_config.ERASURE_MODE) != "disabled"
    threshold = float(recovery_config.CONFIDENCE_THRESHOLD)
    margin_min = float(recovery_config.MIN_COEFF_MARGIN)
    erased = []
    block_erased = np.zeros(64 * 64, dtype=np.float64)
    block_seen = np.zeros(64 * 64, dtype=np.float64)
    tile_seen: dict[int, int] = {}
    tile_kept: dict[int, int] = {}
    for item in raw["copy_results"]:
        conf = float(item["confidence"])
        margin = abs(float(item["margin"]))
        is_erased = mode_enabled and (conf < threshold or margin < margin_min)
        record = {
            "bit_index": int(item["bit_index"]),
            "copy_index": int(item["copy_index"]),
            "block_index": int(item["block_index"]),
            "tile": int(item["tile"]),
            "erased": bool(is_erased),
            "damaged": bool(item.get("damaged", False)),
            "confidence": conf,
            "bit": int(item["bit"]),
            "expected": int(item["expected"]),
        }
        erased.append(record)
        block = int(item["block_index"])
        tile = int(item["tile"])
        block_seen[block] += 1
        tile_seen[tile] = tile_seen.get(tile, 0) + 1
        if is_erased:
            block_erased[block] = 1
        else:
            tile_kept[tile] = tile_kept.get(tile, 0) + 1
    erasure_count = sum(1 for x in erased if x["erased"])
    true_erased = sum(1 for x in erased if x["erased"] and x["damaged"])
    precision = true_erased / erasure_count if erasure_count else 0.0
    erasure_rate = erasure_count / max(1, len(erased))
    survival = {tile: tile_kept.get(tile, 0) / max(1, seen) for tile, seen in tile_seen.items()}
    save_block_map(block_erased, work_path("erasure_confidence_map.png"), positive=(245, 185, 55), negative=(40, 70, 110))
    save_tile_map(survival, work_path("tile_survival_map.png"))
    data = {
        "image": image_name,
        "erasures": erased,
        "erasure_rate": erasure_rate,
        "precision": precision,
        "tile_survival": survival,
    }
    write_json(work_path(Path(image_name).stem + "_erasure.json"), data)
    return data


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", required=True)
    parser.add_argument("--out", default="erasure_report.txt")
    args = parser.parse_args()
    image_name = Path(args.image).name
    data = detect(image_name)
    no_todo = not config_text_has_todo("recovery_config.py")
    accepted = (
        str(recovery_config.ERASURE_MODE) != "disabled"
        and 0.10 <= float(data["erasure_rate"]) <= 0.55
        and float(data["precision"]) >= 0.60
        and no_todo
    )
    lines = [
        "Erasure detection report",
        f"Image: {image_name}",
        f"ERASURE_MODE: {recovery_config.ERASURE_MODE}",
        f"Erasure rate: {data['erasure_rate'] * 100.0:.2f}%",
        f"Erasure detector precision: {data['precision'] * 100.0:.2f}%",
        f"TODO remaining in recovery_config.py: {'NO' if no_todo else 'YES'}",
    ]
    if accepted:
        lines.insert(0, "Erasure blocks detected")
    else:
        lines.append("Status: NOT ACCEPTED - tune recovery_config.py.")
    write_report(work_path(args.out), lines)
    print("\n".join(lines))


if __name__ == "__main__":
    main()

