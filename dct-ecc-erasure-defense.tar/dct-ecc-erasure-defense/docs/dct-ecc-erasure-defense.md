# dct-ecc-erasure-defense

Full title: DCT ECC-Erasure Defense Against Geometric Attacks

This lab teaches robust DCT watermark design without registration. Students build:

- DCT block embedding
- Error correcting redundancy
- Spatial interleaving
- Multi-tile copies
- Confidence-based erasure detection
- Weighted tile recovery

The lab intentionally excludes registration, feature matching, anchors, homography, inverse alignment, and brute-force rotation/scale search.

## Checkwork

The expected Labtainer results are:

```text
Labname dct-ecc-erasure-defense

Y - task1_scene
Y - task2_dct_capacity
Y - task3_block_mask
Y - task4_ecc_design
Y - task5_interleaver
Y - task6_embed_ecc
Y - task7_geometric_damage
Y - task8_raw_extract
Y - task9_erasure_detection
Y - task10_ecc_decode
Y - task11_adaptive_recovery
Y - task12_challenge_recovery
Y - task13_visual_evidence
Y - task14_memo
Y - task15_summary
```

